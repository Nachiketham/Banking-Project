package br.com.carlosjunior.registrationlogin.repositories;


import java.util.List;

import org.springframework.data.repository.CrudRepository;

import br.com.carlosjunior.registrationlogin.entities.PrimaryTransaction;
public interface PrimaryTransactionDao extends CrudRepository<PrimaryTransaction, Long> {

    List<PrimaryTransaction> findAll();
}