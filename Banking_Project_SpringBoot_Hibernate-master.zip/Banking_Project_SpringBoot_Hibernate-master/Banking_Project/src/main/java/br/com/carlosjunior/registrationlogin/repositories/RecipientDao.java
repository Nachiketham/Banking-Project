package br.com.carlosjunior.registrationlogin.repositories;

import org.springframework.data.repository.CrudRepository;

import br.com.carlosjunior.registrationlogin.entities.Recipient;

import java.util.List;


public interface RecipientDao extends CrudRepository<Recipient, Long> {

    List<Recipient> findAll();

    Recipient findByName(String recipientName);

    void deleteByName(String recipientName);
}